export const environment = {
  production: true,
  baseUrl: 'https://major13.herokuapp.com',
};
